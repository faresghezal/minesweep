
#include"Map.h"

int main()
{
   Map game;
   game.~Map();
    return 0;
}
